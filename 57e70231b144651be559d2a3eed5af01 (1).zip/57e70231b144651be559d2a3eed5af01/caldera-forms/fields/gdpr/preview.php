<div class="preview-caldera-config-group">
	<div class="preview-caldera-config-field">
        <div>
            <input type="checkbox" class="preview-field-config">
            <label class="checkbox-inline" style="margin: 0px 10px 0px 0px;">
                {{#unless hide_label}}{{label}}{{/unless}}
                <a style="color:#444;" href="#">{{config.linked_text}}</a>
                <span style="color:#ff0000;">*</span>
            </label>
        </div>
	</div>
</div>